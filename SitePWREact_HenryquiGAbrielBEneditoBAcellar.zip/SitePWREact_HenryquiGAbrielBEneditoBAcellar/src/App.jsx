
import { Header } from "./components/Header"
import styles from "./App.module.css"
import './global.css'
import { Card } from "./components/Card"
import { Banner } from "./components/Banner"

const banner = [
  {
    id : 1,
    banner : {
      bannerimg: "https://int.bape.com/cdn/shop/files/20241123_FW24_BAPE_SHARK_ATTACK_1st_n_2nd_2160x1080_4439df49-8810-4de0-928c-8785c526a63f.jpg?v=1732259747&width=1800"
    }
  },
  {
    id : 2,
    banner : {
      bannerimg: "https://int.bape.com/cdn/shop/files/20241130_FW24_DON_TOLIVER_2160X1080_6261aef1-cc1f-45d3-80c0-989f0f04711a.jpg?v=1732847072&width=1800"
    }
  }
]

const posts = [
{
  id : 1,
  produto : {
    produtoimg : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlwqAn990cnPrzHiZvKYqYWpiynzCQK_t0AA&s",
    nomeproduto : "Camiseta Relva Selvagem",
    edicao : "ED. LIMITADA",
    preco : "129,99R$"
  }
},
{
  id : 2,
  produto : {
    produtoimg : "https://acdn.mitiendanube.com/stores/004/313/571/products/br-11134207-7r98o-lqwc8actiwx051-4125d9443bbba42ec517082212638965-1024-1024.jpeg",
    nomeproduto : "Camiseta Chico Coins",
    edicao : "Primeira ED.",
    preco : "79,99R$"
  }
},
{
  id : 3,
  produto : {
    produtoimg : "https://down-br.img.susercontent.com/file/br-11134207-7r98o-lp9b2q4zzkc2ca",
    nomeproduto : "Camiseta Computaria",
    edicao : "Segunda ED.",
    preco : "99,99R$"
  } 
},
{
  id : 4,
  produto : {
    produtoimg : "https://d1mr3mwm0mcol2.cloudfront.net/eyJidWNrZXQiOiJtb250aW5rIiwia2V5IjoicHJvZHV0b19pbWFnZW5zLzI0NjIwMC9waHA1aG1zVlMucG5nIiwiZWRpdHMiOnsicmVzaXplIjp7ImhlaWdodCI6MzIwLCJ3aWR0aCI6MzIwLCJmaXQiOiJpbnNpZGUifX19",
    nomeproduto : "Camiseta *medo",
    edicao : "",
    preco : "59,99R$"
  } 
}
]

export function App() {
  return (
    <div>
      <Header/>
      <div className={styles.ordened}>
        <main>
          {posts.map(card =>{
            return(
              <Card
              produto = {card.produto}
              />
            )
          })
          }
          </main>
        {banner.map(banner =>{
          return(
            <Banner
            banner = {banner.banner}
            />
          )
        }
        )}
      </div>
    </div>
  )
}
