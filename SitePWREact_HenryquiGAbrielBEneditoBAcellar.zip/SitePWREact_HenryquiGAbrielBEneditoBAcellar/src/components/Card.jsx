import styles from './Card.module.css'

export function Card({produto}){
    return(
        <article className={styles.space}>
         <div className={styles.container}>
            <img src={produto.produtoimg} alt="" />
            <h4>{produto.nomeproduto}</h4>
            <h5>{produto.edicao}</h5>
            <br />
            <p>{produto.preco}</p>         
            <span>Comprar</span>
            
         </div>
        </article>
        
    );
}